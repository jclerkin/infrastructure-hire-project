import boto3
import json
import os

def lambda_handler(event, context):
    sqs = boto3.client('sqs')
    queue_url = os.environ['queue_url']
    for record in event['Records']:
        filename = record['s3']['bucket']['name'] + record['s3']['object']['key']
        print(filename)
        response = sqs.send_message(
            QueueUrl=queue_url,
            MessageBody=json.dumps({
                'bucket' : record['s3']['bucket']['name'],
                'key' :  record['s3']['object']['key']
            })
        )
